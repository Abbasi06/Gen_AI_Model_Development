# To Assess the latency and throughput of Local Deployment
import requests
import time

url = "http://127.0.0.1:8000/generate"
payload = {"text" : "Explain quantum computing in one sentence"}

latencies = []
num_requests = 10

for _ in range(num_requests):
    start_time = time.time()
    response = requests.post(url, json=payload)
    latency = (time.time() - start_time) * 1000
    latencies.append(latency)
    print(f"Request {_+1}/{num_requests} - Latency: {latency:.2f} ms")

if latencies:
    avg_latency = sum(latencies) / len(latencies)
    total_time = sum(latencies) / 1000
    throughput = num_requests / total_time
    print("\n--- Benchmark Complete ---")
    print(f"Total Requests: {num_requests}")
    print(f"Average Latency: {avg_latency:.2f} ms")
    print(f"Total Time: {total_time:.2f} s")
    print(f"Throughput (Req/Sec): {throughput:.2f}")