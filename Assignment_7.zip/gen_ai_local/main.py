# --- Gen-ai Text Generation Application (Local Deployment) ---
from fastapi import FastAPI
from pydantic import BaseModel
from transformers import pipeline
import time

# --- Loading the model once when the application starts ---
print("Loading text-generation model GPT-2")
generator = pipeline("text-generation", model="gpt2")
print("Model loaded Successfully")


# Initializing the application
app = FastAPI(title= "Generative AI API", description= "An API to serve a Gen-AI model", version = "1.0")

# Using Pydantic's BaseModel to validate the datatype our POST requests expect to receive
class PromptRequest(BaseModel):
    prompt: str
    max_length: int = 50

# API Endpoints
@app.get("/")
def read_root():
    """A simple check to see if the API is running or not"""
    return {"Generative AI API is running sucessfully"}

@app.post("/generate")
def generate_text(request: PromptRequest):
    """Endpoint to generate text. It takes a JSON request with text and max length
       and returns the generated text"""
    start_time = time.time()
    output = generator(request.prompt, max_length=request.max_length)
    latency = ((time.time()) - start_time) * 1000 #in milliseconds

    generated_text = output[0]['generated_text']

    return {"generated_text": generated_text, "latency": f"{latency:.2f}"}

    






